# movie-recommender-system-tmdb-dataset
A content based movie recommender system using cosine similarity
This file isn't complete this is just notebooks and app created in python 
